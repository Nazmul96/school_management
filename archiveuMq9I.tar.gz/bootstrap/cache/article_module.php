<?php return array (
  'providers' => 
  array (
    0 => 'Modules\\Article\\Providers\\ArticleServiceProvider',
    1 => 'Modules\\Article\\Providers\\EventServiceProvider',
  ),
  'eager' => 
  array (
    0 => 'Modules\\Article\\Providers\\ArticleServiceProvider',
    1 => 'Modules\\Article\\Providers\\EventServiceProvider',
  ),
  'deferred' => 
  array (
  ),
);