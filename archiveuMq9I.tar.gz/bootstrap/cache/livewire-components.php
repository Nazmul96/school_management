<?php return array (
  'users-index' => 'App\\Http\\Livewire\\UsersIndex',
);